[logo]: https://pbs.twimg.com/profile_banners/2831158663/1509496810/600x200 "Logo"
![alt text][logo]

XX Artists Experience

# Project Details
Type: 
- Static HTML

Library:
- [jQuery](https://code.jquery.com/)
- [Bootstrap](https://getbootstrap.com/docs/4.3/getting-started/introduction/)

Typography:
- [FontAwesome](https://fontawesome.com)
- [nobel](https://use.typekit.net/fjy7rod.css)